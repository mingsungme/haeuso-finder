
  # 해우소 찾기

  This is a code bundle for 해우소 찾기. The original project is available at https://www.figma.com/design/nuiatFRMRDvb2K4wzv6ikV/%ED%95%B4%EC%9A%B0%EC%86%8C-%EC%B0%BE%EA%B8%B0.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  